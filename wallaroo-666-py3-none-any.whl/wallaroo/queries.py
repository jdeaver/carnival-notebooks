from importlib import resources
import os

from . import graphql


def named(name: str) -> str:
    return resources.read_text(graphql, f"{name}.graphql")
