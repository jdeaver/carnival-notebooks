from .object import *
from . import queries

from typing import cast, Any, Dict, List, TYPE_CHECKING

from .user import User
from .model import Model
from .pipeline import Pipeline

if TYPE_CHECKING:
    # Imports that happen below in methods to fix circular import dependency
    # issues need to also be specified here to satisfy mypy type checking.
    from .client import Client


class Tag(Object):
    """Tags that may be attached to models and pipelines."""

    def __init__(
        self, client: Optional["Client"], data: Dict[str, Any], standalone=False
    ) -> None:
        self.client = client
        super().__init__(
            gql_client=client._gql_client if client is not None else None,
            data=data,
            standalone=standalone,
        )

    @staticmethod
    def _create_tag(client, tag_text: str):
        res = client._gql_client.execute(
            gql.gql(queries.named("CreateTag")),
            variable_values={
                "tag_text": tag_text,
            },
        )
        return Tag(client, res["insert_tag"]["returning"][0])

    def _fill(self, data: Dict[str, Any]) -> None:
        """Fills an object given a response dictionary from the GraphQL API.

        Only the primary key member must be present; other members will be
        filled in via rehydration if their corresponding member function is
        called.
        """
        for required_attribute in ["id"]:
            if required_attribute not in data:
                raise RequiredAttributeMissing(
                    self.__class__.__name__, required_attribute
                )
        # Required
        self._id = data["id"]

        # Optional
        self._tag = value_if_present(data, "tag")

    def _fetch_attributes(self) -> Dict[str, Any]:
        """Fetches all member data from the GraphQL API."""
        return self._gql_client.execute(
            gql.gql(
                f"""
            query TagById {{
                tag_by_pk(id: {self._id}) {{
                    id
                    tag
                }}
            }}
            """
            )
        )["tag_by_pk"]

    def id(self) -> int:
        return self._id

    @rehydrate("_tag")
    def tag(self) -> str:
        return cast(str, self._tag)

    def list_models(self) -> List[Model]:
        """Lists the models this tag is on."""
        res = self._gql_client.execute(
            gql.gql(
                """
            query TagById($tag_id: bigint!){
            tag_by_pk(id:$tag_id){
                model_tags {
                model {
                    model_id
                    model_version
                    sha
                file_name
                    updated_at
                    visibility
                }
                }
            }
            }
            """
            )
        )
        list_of_models = []
        for v in res["tag_by_pk"]["model_tags"]:
            list_of_models.append(Model(client=self.client, data=v["model"]))
        return list_of_models

    def add_to_model(self, tag_id: int):
        data = self._gql_client.execute(
            gql.gql(
                """
            mutation AddTagToModel($model_id: bigint!, $tag_id: bigint!) {
            insert_model_tag(objects: {
                model_id : $model_id,
           		  tag_id: $tag_id
            }) {
                returning {
                    model_id
                    tag_id
                }
            }
            }            
            """
            ),
            variable_values={
                "model_id": self._id,
                "tag_id": tag_id,
            },
        )
        return data["insert_model_tag"]["returning"][0]

    def remove_from_model(self, model_id: int):
        data = self._gql_client.execute(
            gql.gql(
                """
            mutation RemoveTagFromModel($model_id: bigint!, $tag_id: bigint!) {
            delete_model_tag(
                    where: {
                        _and: [
                            { model_id: {_eq: $model_id} } 
                            { tag_id: {_eq: $tag_id} }
                        ]
                    }
                    ) 
                {
                returning {
                    model_id
                    tag_id
                }

                }

            }
            """
            ),
            variable_values={
                "model_id": model_id,
                "tag_id": self._id,
            },
        )
        return data["delete_model_tag"]["returning"][0]
        #     raise EntityNotFoundError("Tag", {"model_id": model_id})

    def add_to_pipeline(self, pipeline_id: int):
        data = self._gql_client.execute(
            gql.gql(
                """
            mutation AddTagToPipeline($pipeline_id: bigint!, $tag_id: bigint!) {
            insert_pipeline_tag(objects: {
                pipeline_pk_id : $pipeline_id,
           		  tag_pk_id: $tag_id
            }) {
                returning {
                    pipeline_pk_id
                    tag_pk_id
                }
            }
            }            
            """
            ),
            variable_values={
                "pipeline_id": pipeline_id,
                "tag_id": self._id,
            },
        )
        return data["insert_pipeline_tag"]["returning"][0]

    def remove_from_pipeline(self, model_id: int):
        data = self._gql_client.execute(
            gql.gql(
                """
            mutation RemoveTagFromPipeline($pipeline_id: bigint!, $tag_id: bigint!) {
            delete_pipeline_tag(
                    where: {
                        _and: [
                            { pipeline_pk_id: {_eq: $pipeline_id} } 
                            { tag_pk_id: {_eq: $tag_id} }
                        ]
                    }
                    ) 
                {
                returning {
                    model_pk_id
                    tag_pk_id
                }

                }

            }
            """
            ),
            variable_values={
                "model_pk_id": model_id,
                "tag_pk_id": self._id,
            },
        )
        return data["delete_pipeline_tag"]["returning"][0]
