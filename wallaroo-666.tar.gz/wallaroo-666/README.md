# Python SDK for Wallaroo


This repo contains the python SDK used to interface with the Wallaroo API. The structure is as follows:

- Package name: Wallaroo
- Modules contained: sdk
- [SDK documentation](https://wallaroolabs.github.io/wallaroo-docs/sdk.html)

## Tests
Before running tests, you'll need to:

```sh
pip3 install -r requirements.txt
pip3 install -r requirements-dev.txt
```

To execute all tests run:

```sh
pytest
```

To execute a specific test run, for example:

```sh
pytest -k test_client
```

To update snapshots used for testing, you can run:

```sh
pytest -k test_checks --snapshot-update
```

## Build

Make sure you have the latest version of 'build'
```sh
make build-sdk
```
This will generate a distribution package in the dist directory.

## Generate Documentation

pdoc3 is used to generate the documentation for the SDK.
To generate the documentation run:
```sh
make doc
```
This will generate documentation files in the [html](html) directory


To remove generated files:
```sh
make clean
```

## readthedocs.com Documentation

Extensive user-facing documentation is hosted by [ReadTheDocs](https://readthedocs.com). The system is configured to point to the `platform` repo. Documentation can be generated for a specific branch or tag by going to the [Versions](https://readthedocs.com/projects/wallaroo-platform/versions/) page and activating the version.

Release documentation can be published by activing the tag that corresponds to the release and changing the "Privacy Level" to `Public`.
