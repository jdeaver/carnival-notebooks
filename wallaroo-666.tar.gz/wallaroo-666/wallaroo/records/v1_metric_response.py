# To use this code, make sure you
#
#     import json
#
# and then, to convert JSON from a string, do
#
#     result = wallaroo_telemetry_metric_query_v1_from_dict(json.loads(json_string))
#  npx quicktype --src api/json/telemetry/wallaroo-telemetry-metric-query-v1.json  --src-lang schema --lang python  > sdk/wallaroo/records/v1_metric_response.json

from typing import Any, List, TypeVar, Callable, Type, cast


T = TypeVar("T")


def from_str(x: Any) -> str:
    assert isinstance(x, str)
    return x


def from_list(f: Callable[[Any], T], x: Any) -> List[T]:
    assert isinstance(x, list)
    return [f(y) for y in x]


def from_int(x: Any) -> int:
    assert isinstance(x, int) and not isinstance(x, bool)
    return x


def to_class(c: Type[T], x: Any) -> dict:
    assert isinstance(x, c)
    return cast(Any, x).to_dict()


class MetricQuery:
    """The alias for this query. Used for grouping metric results together"""

    alias: str
    """The prometheus query to run"""
    query: str

    def __init__(self, alias: str, query: str) -> None:
        self.alias = alias
        self.query = query

    @staticmethod
    def from_dict(obj: Any) -> "MetricQuery":
        assert isinstance(obj, dict)
        alias = from_str(obj.get("alias"))
        query = from_str(obj.get("query"))
        return MetricQuery(alias, query)

    def to_dict(self) -> dict:
        result: dict = {}
        result["alias"] = from_str(self.alias)
        result["query"] = from_str(self.query)
        return result


class WallarooTelemetryMetricQueryV1:
    metrics: List[MetricQuery]
    """Post metrics on this minute, 0 is every minute."""
    run_on_minute: int

    def __init__(self, metrics: List[MetricQuery], run_on_minute: int) -> None:
        self.metrics = metrics
        self.run_on_minute = run_on_minute

    @staticmethod
    def from_dict(obj: Any) -> "WallarooTelemetryMetricQueryV1":
        assert isinstance(obj, dict)
        metrics = from_list(MetricQuery.from_dict, obj.get("metrics"))
        run_on_minute = from_int(obj.get("runOnMinute"))
        return WallarooTelemetryMetricQueryV1(metrics, run_on_minute)

    def to_dict(self) -> dict:
        result: dict = {}
        result["metrics"] = from_list(lambda x: to_class(MetricQuery, x), self.metrics)
        result["runOnMinute"] = from_int(self.run_on_minute)
        return result


def wallaroo_telemetry_metric_query_v1_from_dict(
    s: Any,
) -> WallarooTelemetryMetricQueryV1:
    return WallarooTelemetryMetricQueryV1.from_dict(s)


def wallaroo_telemetry_metric_query_v1_to_dict(
    x: WallarooTelemetryMetricQueryV1,
) -> Any:
    return to_class(WallarooTelemetryMetricQueryV1, x)
