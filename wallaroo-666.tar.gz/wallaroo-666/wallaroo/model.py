from .object import *

import datetime
from typing import TYPE_CHECKING, cast, Any, Dict, List, Optional

from .checks import Variables, require_dns_compliance
from dateutil import parser as dateparse
from .deployment_config import DeploymentConfig, DeploymentConfigBuilder
import gql  # type: ignore

from .deployment_config import DeploymentConfig
from .logs import LogEntries
from .visibility import _Visibility

if TYPE_CHECKING:
    # Imports that happen below in methods to fix circular import dependency
    # issues need to also be specified here to satisfy mypy type checking.
    from .client import Client
    from .deployment import Deployment
    from .model_config import ModelConfig
    from .pipeline import Pipeline


class Model(Object):
    """Wraps a backend Model object."""

    def __init__(
        self, client: Optional["Client"], data: Dict[str, Any], standalone=False
    ) -> None:
        self.client = client
        self._config: Optional["ModelConfig"] = None
        super().__init__(
            gql_client=client._gql_client if client is not None else None,
            data=data,
            standalone=standalone,
        )

    def __repr__(self) -> str:
        return str(
            {
                "name": self.name(),
                "version": self.version(),
                "file_name": self.file_name(),
                "last_update_time": self.last_update_time(),
            }
        )

    @staticmethod
    def as_standalone(name: str, version: str, file_name: str) -> "Model":
        """Creates a Model intended for use in generating standalone configurations"""
        constructor_dict = {
            "model_id": name,
            "model_version": version,
            "file_name": file_name,
            "id": -1,
        }
        return Model(None, constructor_dict, standalone=True)

    def _fill(self, data: Dict[str, Any]) -> None:
        """Fills an object given a response dictionary from the GraphQL API.

        Only the primary key member must be present; other members will be
        filled in via rehydration if their corresponding member function is
        called.
        """
        for required_attribute in ["id"]:
            if required_attribute not in data:
                raise RequiredAttributeMissing(
                    self.__class__.__name__, required_attribute
                )
        # Required
        self._id = data["id"]

        # Optional
        self._name = value_if_present(data, "model_id")
        self._version = value_if_present(data, "model_version")
        self._sha = value_if_present(data, "sha")
        self._file_name = value_if_present(data, "file_name")
        self._last_update_time = (
            dateparse.isoparse(data["updated_at"])
            if "updated_at" in data
            else DehydratedValue()
        )
        self._visibility = (
            _Visibility.from_str(data["visibility"])
            if "visibility" in data
            else DehydratedValue()
        )

    def _fetch_attributes(self) -> Dict[str, Any]:
        """Fetches all member data from the GraphQL API."""
        return self._gql_client.execute(
            gql.gql(
                f"""
            query ModelById {{
                model_by_pk(id: {self._id}) {{
                    id
                    model_id
                    model_version
                    sha
                    file_name
                    updated_at
                    visibility
                }}
            }}
            """
            )
        )["model_by_pk"]

    def id(self) -> int:
        return self._id

    @rehydrate("_name")
    def name(self) -> str:
        return cast(str, self._name)

    @rehydrate("_version")
    def version(self) -> str:
        return cast(str, self._version)

    @rehydrate("_sha")
    def sha(self) -> str:
        return cast(str, self._sha)

    @rehydrate("_file_name")
    def file_name(self) -> str:
        return cast(str, self._file_name)

    @rehydrate("_last_update_time")
    def last_update_time(self) -> datetime.datetime:
        return cast(datetime.datetime, self._last_update_time)

    @property
    def inputs(self):
        return Variables(self.name(), "input")

    @property
    def outputs(self):
        return Variables(self.name(), "output")

    def _update_visibility(self, visibility: _Visibility):
        assert self.client is not None
        return self._fill(
            self.client._gql_client.execute(
                gql.gql(
                    """
                mutation UpdateModelVisibility(
                    $model_pk: bigint!,
                    $visibility: String
                ) {
                  update_model(where: {id: {_eq: $model_pk}}, _set: {visibility: $visibility}) {
                        returning {
                          id
                          model_id
                          model_version
                          file_name
                          visibility
                          updated_at
                        }
                    }
                }
                """
                ),
                variable_values={
                    "model_pk": self._id,
                    "visibility": visibility,
                },
            )["update_model"]["returning"][0]
        )

    def config(self) -> "ModelConfig":
        if self._config is None:
            self.configure()
        return cast("ModelConfig", self._config)

    def configure(
        self,
        runtime: Optional[str] = None,
        tensor_fields: List[str] = None,
        filter_threshold: float = None,
    ) -> "Model":
        from .model_config import ModelConfig  # Avoids circular imports

        if runtime is None:
            filename_to_runtime = {".onnx": "onnx", ".py": "python"}

            runtimes = [
                v
                for (k, v) in filename_to_runtime.items()
                if self.file_name().endswith(k)
            ]
            if not runtimes:
                raise DeploymentError(
                    f"runtime cannot be inferred from filename: {self.file_name()}"
                )
            if len(runtimes) > 1:
                raise DeploymentError(
                    f"Multiple runtimes possible for filename {self.file_name()}: {runtimes}"
                )
            runtime = runtimes[0]

        # Format the string array for postgresql
        tensor_fields_var = None
        if tensor_fields is not None:
            tensor_fields_var = f"{{{' '.join(tensor_fields)}}}"

        q = gql.gql(
            """
            mutation ConfigureModel($model_id: bigint!, $runtime: String, $tensor_fields: _text, $filter_threshold: float8) {
                insert_model_config(objects: {filter_threshold: $filter_threshold, model_id: $model_id, runtime: $runtime, tensor_fields: $tensor_fields}) {
                returning {
                    id
                    model_id
                    runtime
                    tensor_fields
                    filter_threshold
                    model {
                        id
                    }
                }
            }
            }
            """
        )
        variables = {
            "model_id": self.id(),
            "runtime": runtime,
            "tensor_fields": tensor_fields_var,
            "filter_threshold": filter_threshold,
        }
        assert self.client is not None
        data = self.client._gql_client.execute(q, variable_values=variables)

        self._config = ModelConfig(
            client=self.client,
            data=data["insert_model_config"]["returning"][0],
        )
        self._config._model = self
        return self

    def logs(self, limit: int = 100, valid: Optional[bool] = None) -> LogEntries:
        topic = f"model-{self.name()}-inference"
        if valid is False:
            topic += "-failures"
        assert self.client is not None
        return self.client.get_logs(topic, limit)

    def deploy(
        self,
        pipeline_name: str,
        deployment_config: Optional[DeploymentConfig] = None,
    ) -> "Pipeline":
        """Convenience function to quickly deploy a Model. It will configure the model,
        create a pipeline with a single model step, deploy it, and return the pipeline.

        Typically, the configure() method is used to configure a model prior to
        deploying it. However, if a default configuration is sufficient, this
        function can be used to quickly deploy with said default configuration.

        The filename this Model was generated from needs to have a recognizable
        file extension so that the runtime can be inferred. Currently, this is:

        * `.onnx` -> ONNX runtime

        :param str deployment_name: Name of the deployment to create. Must be
            unique across all deployments. Deployment names must be ASCII alpha-numeric
            characters plus dash (-) only.

        """

        from .pipeline import Pipeline
        from .pipeline_config import PipelineConfigBuilder
        from .pipeline_config import PipelineConfig

        assert self.client is not None

        require_dns_compliance(pipeline_name)

        if deployment_config is None:
            deployment_config = DeploymentConfigBuilder().build()

        pipeline = self.client.build_pipeline(pipeline_name)

        pipeline.add_model_step(self)

        pipeline.deploy(pipeline_name, deployment_config=deployment_config)

        return pipeline

        # TODO - wait_for_running
