import json
import re
import sys
import time
from typing import cast, Any, Dict, Iterator, List, Optional, Union, TYPE_CHECKING

from .auth import _NoAuth, _PlatformAuth
from .object import *
from .inference_result import InferenceResult
from .logs import LogEntries, LogEntry
from .model_config import ModelConfig

import aiohttp
import asyncio
import gql  # type: ignore
import numpy
import orjson
import pathlib
import psycopg2  # type: ignore
import pypika  # type: ignore
from pypika.functions import Cast  # type: ignore
from pypika.terms import JSON  # type: ignore
from pypika import Order, Query, Table  # type: ignore
import requests


class JsonArrayLength(pypika.terms.Function):
    def __init__(self, json):
        super().__init__("JSONB_ARRAY_LENGTH", json)


class RegexpReplace(pypika.terms.Function):
    def __init__(self, term, pattern, replacement):
        super().__init__("REGEXP_REPLACE", term, pattern, replacement)


if TYPE_CHECKING:
    from .client import Client
    from .model import Model
    from .pipeline_variant import PipelineVariant


class Deployment(Object):
    def __init__(self, client: Optional["Client"], data: Dict[str, Any]) -> None:
        self.client = client
        assert client is not None
        super().__init__(gql_client=client._gql_client, data=data)

    def _fill(self, data: Dict[str, Any]) -> None:
        """Fills an object given a response dictionary from the GraphQL API.

        Only the primary key member must be present; other members will be
        filled in via rehydration if their corresponding member function is
        called.
        """
        from .pipeline_variant import PipelineVariant  # avoids circular imports

        for required_attribute in ["id"]:
            if required_attribute not in data:
                raise RequiredAttributeMissing(
                    self.__class__.__name__, required_attribute
                )
        self._id = data["id"]

        self._name = value_if_present(data, "deploy_id")
        self._deployed = value_if_present(data, "deployed")
        self._model_configs = (
            [
                ModelConfig(self.client, elem["model_config"])
                for elem in data["deployment_model_configs"]
            ]
            if "deployment_model_configs" in data
            else DehydratedValue()
        )
        self._pipeline_variants = (
            [
                PipelineVariant(self.client, elem["pipeline_version"])
                for elem in data["deployment_pipeline_versions"]
            ]
            if "deployment_pipeline_versions" in data
            else DehydratedValue()
        )

        self._pipeline_id = value_if_present(data, "pipeline_id")

    def _fetch_attributes(self) -> Dict[str, Any]:
        """Fetches all member data from the GraphQL API."""
        return self._gql_client.execute(
            gql.gql(
                """
            query DeploymentById($deployment_id: bigint!) {
                deployment_by_pk(id: $deployment_id) {
                    id
                    deploy_id
                    deployed
                    deployment_model_configs {
                        model_config {
                            id
                        }
                    }
                    deployment_pipeline_versions(order_by: {pipeline_version: {id: desc}}) {
                        pipeline_version {
                            id
                        }
                    }
                }
            }
            """
            ),
            variable_values={
                "deployment_id": self._id,
            },
        )["deployment_by_pk"]

    def id(self) -> int:
        return self._id

    @rehydrate("_name")
    def name(self) -> str:
        return cast(str, self._name)

    @rehydrate("_deployed")
    def deployed(self) -> bool:
        return cast(bool, self._deployed)

    @rehydrate("_model_configs")
    def model_configs(self) -> List[ModelConfig]:
        return cast(List[ModelConfig], self._model_configs)

    @rehydrate("_pipeline_variants")
    def pipeline_variants(self) -> List["PipelineVariant"]:
        from .pipeline_variant import PipelineVariant  # avoids circular imports

        return cast(List[PipelineVariant], self._pipeline_variants)

    def deploy(self) -> "Deployment":
        """Deploys this deployment, if it is not already deployed.

        If the deployment is already deployed, this is a no-op.
        """
        q = gql.gql(
            """
        mutation Deploy($id: bigint!) {
            update_deployment_by_pk(pk_columns: {id: $id} _set: { deployed: true }) {
                id
                deploy_id
                deployed
            }
        }
        """
        )
        variables = {"id": self.id()}
        assert self.client is not None
        self.client._gql_client.execute(q, variable_values=variables)
        self._rehydrate()
        return self

    def undeploy(self) -> "Deployment":
        """Shuts down this deployment, if it is deployed.

        If the deployment is already undeployed, this is a no-op.
        """
        q = gql.gql(
            """
        mutation Deploy($id: bigint!) {
            update_deployment_by_pk(pk_columns: {id: $id} _set: { deployed: false }) {
                id
                deploy_id
                deployed
            }
        }
        """
        )
        variables = {"id": self.id()}
        self._gql_client.execute(q, variable_values=variables)
        self._rehydrate()
        return self

    def _get_auth(self):
        # TODO: Digging the auth object out of the gql_client is cheating
        return self.client._gql_client.transport.auth

    def status(self) -> Dict[str, Any]:
        """Returns a dict of deployment status useful for determining if a deployment has succeeded.

        :return: Dict of deployment internal state information.
        :rtype: Dict[str, Any]
        """

        assert self.client is not None

        status_url = f"{self.client.api_endpoint}/v1/status/deployments/{self.name()}-{self.id()}"

        try:
            resp = requests.get(
                status_url,
                timeout=1,
                auth=self._get_auth(),
            )
        except Exception as ex:
            raise CommunicationError(f"rest-api connection to {status_url}")

        if resp.status_code == 404:
            raise EntityNotFoundError(f"Deployment not found", {"name": self.name()})

        if resp.status_code != 200:
            raise RuntimeError(f"Unable to query deployment status {status_url}")

        return resp.json()

    def check_limit_status(self):
        q = gql.gql(
            """
            query QueryLimitStatus($id: bigint!) {
                deployment(where: {id: {_eq: $id}}) {
                    id
                    deployed
                    limit_status
                }
            }
            """
        )

        variables = {"id": self.id()}
        assert self.client is not None
        res = self.client._gql_client.execute(q, variable_values=variables)[
            "deployment"
        ]
        if len(res) > 0:
            status = res[0]
            if "limit_status" in status:
                limit_status = status["limit_status"]
                if limit_status is not None:
                    raise LimitError(limit_status)

    def wait_for_running(self) -> "Deployment":
        """Waits for the deployment status to enter the "Running" state.

        Will wait up "timeout_request" seconds for the deployment to enter that state. This is set
        in the "Client" object constructor. Will raise various exceptions on failures.

        :return: The deployment, for chaining.
        :rtype: Deployment
        """
        assert self.client is not None
        warning = False
        duration = self.client.timeout
        message = "(none)"
        kind = "unset"

        for ix in range(duration + 1):
            # If this checks immediately, it will happen too soon for the deployment manager to
            # have cleared the limit_status column on the deployment and this will fail erroneously
            if ix > 5:
                self.check_limit_status()

            try:
                res = self.status()
                if res is not None and res["status"] == "Running":
                    if self.client._interactive:
                        sys.stdout.write(" ok\n")
                    return self
                message = "not running"
                kind = "runtime"
            except CommunicationError as ex:
                # Connection may be coming up, try again
                message = str(ex)
                kind = "comm"
            except (EntityNotFoundError, RuntimeError) as ex:
                # Not found may switch to found, after a while. Retry it.
                message = f"not found {ex}"
                kind = "runtime"
            if self.client._interactive:
                if not warning:
                    sys.stdout.write(
                        f"Waiting for deployment - this will take up to {duration}s "
                    )
                    warning = True
                time.sleep(1)
                sys.stdout.write(".")
            else:
                time.sleep(
                    1
                )  # functionally unnecessary but preserving the timing for validation

        if kind == "comm":
            raise CommunicationError(message)
        else:
            try:
                message = str(self.status())
            except:
                message = f"Deployment did not come up within {duration}s, {message}.\nSee client.pipelines_by_name('{self.name()}')[0].status() for details."
            raise RuntimeError(message)

    def infer(self, tensor: Dict[str, Any]) -> List[InferenceResult]:
        """Returns an inference result on this deployment.

        :param tensor Dict[str, Any]: Inference dictionary. Example:
            {
                "tensor": [
                    [
                        1.0678324729342086,
                        0.21778102664937624,
                        -1.7115145261843976,
                        0.6822857209662413,
                        1.0138553066742804,
                        -0.43350000129006655,
                        0.7395859436561657,
                        -0.28828395953577357,
                        -0.44726268795990787,
                        0.5146124987725894,
                        0.3791316964287545,
                        0.5190619748123175,
                        -0.4904593221655364,
                        1.1656456468728567,
                        -0.9776307444180006,
                        -0.6322198962519854,
                        -0.6891477694494687,
                        0.17833178574255615,
                        0.1397992467197424,
                        -0.35542206494183326,
                        0.4394217876939808,
                        1.4588397511627804,
                        -0.3886829614721505,
                        0.4353492889350186,
                        1.7420053483337175,
                        -0.4434654615252943,
                        -0.15157478906219238,
                        -0.26684517248765616,
                        -1.4549617756124493
                    ],
                ],
            }
        """
        if not isinstance(tensor, dict):
            raise TypeError(f"tensor is {type(tensor)} but 'dict' is required")
        assert self.client is not None

        url = self._url()
        warning = False
        duration = self.client.timeout
        for ix in range(duration + 1):
            res = None
            try:
                res = requests.post(
                    url,
                    json=tensor,
                    timeout=1,
                    # TODO: Digging the auth object out of the gql_client is cheating
                    auth=self._get_auth(),
                )
                data = res.json()
                break
            except (requests.exceptions.RequestException, json.JSONDecodeError):
                if self.client._interactive:
                    if not warning:
                        sys.stdout.write(
                            f"Waiting for inference response - this will take up to {duration}s "
                        )
                        warning = True
                    sys.stdout.write(".")
                time.sleep(1)
        if ix == duration:
            raise RuntimeError(f"Inference did not return within {duration}s")
        if warning and self.client._interactive:
            sys.stdout.write(" ok\n")
        return [InferenceResult(self._gql_client, d) for d in data]

    def infer_from_file(
        self, filename: Union[str, pathlib.Path]
    ) -> List[InferenceResult]:
        if not isinstance(filename, pathlib.Path):
            filename = pathlib.Path(filename)
        with filename.open("rb") as f:
            tensor = json.load(f)
        return self.infer(tensor)

    async def batch_infer_from_file(
        self,
        filename: Union[str, pathlib.Path],
        data_key: str = "tensor",
        batch_size: int = 1000,
        connector_limit: int = 4,
    ) -> List[InferenceResult]:
        """Async method to run batched inference on a data file for a given deployment.

        :param str filename: path to an existing file with tensor data in JSON format.
        :param str data_key: key which the tensor data is under within the JSON. defaults to "tensor".
        :param int batch_size: batch size to use when sending requests to the engine. defaults to 1000.
        :param int connector_limit: limit for the amount of TCP connections. defaults to 4.
        :return: List of InferenceResult's.
        :rtype: List[InferenceResult]
        """
        if not isinstance(filename, pathlib.Path):
            filename = pathlib.Path(filename)
        with filename.open("rb") as f:
            json_data = orjson.loads(f.read())

        input_data = json_data[data_key]
        chunked_data = self._generate_chunk_data(input_data, batch_size, data_key)

        assert self.client is not None
        url = self._url()
        auth = self._get_auth()
        connector = aiohttp.TCPConnector(limit=connector_limit)

        headers = {}
        if isinstance(auth, _PlatformAuth):
            headers = auth.auth_header()

        async with aiohttp.ClientSession(
            connector=connector,
            headers=headers,
            json_serialize=lambda x: orjson.dumps(x).decode(),
        ) as session:
            requests = []
            for i, chunk in enumerate(chunked_data):
                requests.append(
                    asyncio.ensure_future(self._batch_infer(session, url, chunk))
                )

            resps = await asyncio.gather(*requests)
            return [InferenceResult(self._gql_client, resp) for resp in resps]

    def _chunk_data(self, data: Any, batch_size: int) -> Iterator[List[Any]]:
        for i in range(0, len(data), batch_size):
            yield data[i : i + batch_size]

    def _key_data(self, key: str, data: Any) -> Dict[str, Any]:
        return {key: data}

    def _generate_chunk_data(
        self, data: Dict[str, Any], batch_size: int, key: str
    ) -> Iterator[Dict[str, Any]]:
        chunked_data = self._chunk_data(data, batch_size)
        return (self._key_data(key, chunk) for chunk in chunked_data)

    async def _batch_infer(
        self, session: aiohttp.ClientSession, url: str, batch_data: Dict[str, Any]
    ):
        if not isinstance(batch_data, dict):
            raise TypeError(f"tensor is {type(batch_data)} but 'dict' is required")
        async with session.post(url, json=batch_data) as resp:
            resp_data = await resp.json(content_type=None)
            # NOTE: resp data comes back in a list, returning first elem for parity with requests resp
            return resp_data[0]

    def replace_model(self, model: "Model") -> "Deployment":
        """Replaces the current model with a default-configured Model.

        :param Model model: Model variant to replace current model with
        """
        return self.replace_configured_model(model.config())

    def replace_configured_model(self, model_config: ModelConfig) -> "Deployment":
        """Replaces the current model with a configured variant.

        :param ModelConfig model_config: Configured model to replace current model with
        """
        data = self._gql_client.execute(
            gql.gql(
                """
            mutation ReplaceModel($deployment_id: bigint!, $model_config_id: bigint!) {
                insert_deployment_model_configs(objects: {deployment_id: $deployment_id, model_config_id: $model_config_id}) {
                    returning {
                        id
                        deployment_id
                        model_config_id
                    }
                }
            }
        """
            ),
            variable_values={
                "deployment_id": self.id(),
                "model_config_id": model_config.id(),
            },
        )
        self._rehydrate()
        return self

    def url(self) -> str:
        """Returns the inference URL.

        If both pipelines and models are configured on the Deployment, this
        gives preference to pipelines. The returned URL is always for the first
        configured pipeline or model.
        """
        return self._url()

    def _url(self) -> str:
        return (
            f"http://engine-lb.{self.name()}-{self.id()}:29502/pipelines/{self.name()}"
        )

    def logs(self, limit: int = 100, valid: Optional[bool] = None) -> LogEntries:
        """Fetch log entries from this deployment.

        This function is highly experimental, is unsupported/untested, and may
        change/disappear in the near future.

        This function only works on an in-cluster Jupyter notebook.

        This function only works for deployments of models (not of pipelines).
        """
        logs = pypika.Table("fluentbit")
        parsed_log = Cast(
            RegexpReplace(logs.data.get_text_value("log"), "^.*?{", "{"), "jsonb"
        ).as_("log_data")
        combined = Query.from_(logs.select(logs.time, parsed_log)).as_("sq0")
        audit_data = JSON.get_json_value(combined.log_data, "audit_data")
        audit_data = audit_data.as_("audit_data")

        log_model_id = JSON.get_text_value(audit_data, "model_id")

        model_ids = [mc.model().name() for mc in self.model_configs()]

        q = (
            combined.orderby(combined.time, order=pypika.Order.desc)
            .select(combined.log_data)
            .where(JSON.has_key(combined.log_data, "audit_data"))
            # XXX: this gets all logs for all model variants in the deployment.
            # We currently have no way of scoping this call to this particular
            # deployment.
            .where(log_model_id.isin(model_ids))
            .limit(limit)
        )

        if valid is not None:
            check_failures = JsonArrayLength(
                JSON.get_json_value(audit_data, "check_failures")
            )
            q = q.where(check_failures == 0 if valid else check_failures != 0)

        query_str = q.get_sql()
        args: List = []

        # TODO: Expose this via the API so that direct DB access isn't needed.
        conn = psycopg2.connect(
            "dbname=postgres user=postgres password=password host=postgres port=5432"
        )
        cur = conn.cursor()
        cur.execute(query_str, args)
        res = cur.fetchall()
        cur.close()
        conn.close()
        # Extract JSON from returned rows
        json_rows = [r[0]["audit_data"] for r in res]
        return LogEntries([LogEntry(l) for l in json_rows])
