from typing import Any, Callable, Dict, Optional
import json, os


class DeploymentConfig(Dict):
    pass


class DeploymentConfigBuilder(object):
    def __init__(self) -> None:
        self._config: Dict[str, Any] = {"engine": {}, "enginelb": {}}
        env_config = os.environ.get("DEPLOYMENT_CONFIG", None)
        if env_config:
            conf = json.loads(env_config)
            setters: Dict[str, Callable[[Any], Any]] = {
                "image": self.image,
                "replicas": self.replica_count,
                "autoscale": self._autoscale,
                "cpus": self.cpus,
                "memory": self.memory,
                "lb_cpus": self.lb_cpus,
                "lb_memory": self.lb_memory,
            }
            for key, set in setters.items():
                if key in conf:
                    set(conf[key])

    def image(self, image: str) -> "DeploymentConfigBuilder":
        self._config["engine"]["image"] = image
        return self

    def replica_count(self, count: int) -> "DeploymentConfigBuilder":
        if (
            "autoscale" in self._config["engine"]
            and self._config["engine"]["autoscale"]["replica_max"] < count
        ):
            raise RuntimeError(
                "Replica count must be less than or equal to replica max. Use replica_autoscale_min_max to adjust this."
            )
        self._config["engine"]["replicas"] = count
        return self

    def _autoscale(self, autoscale: Dict[str, Any]):
        self._config["engine"]["autoscale"] = autoscale
        return self

    def replica_autoscale_min_max(self, maximum: int, minimum: int = 0):
        """Configures the minimum and maximum for autoscaling"""
        if minimum > maximum:
            raise RuntimeError("Minimum must be less than or equal to maximum")
        if minimum < 0:
            raise RuntimeError("Minimum must be at least 0")
        if "autoscale" not in self._config["engine"]:
            self._config["engine"]["autoscale"] = {}
        if (
            "replicas" in self._config["engine"]
            and self._config["engine"]["replicas"] > maximum
        ):
            raise RuntimeError(
                "Maximum must be greater than or equal to number of replicas"
            )
        self._config["engine"]["autoscale"]["replica_min"] = minimum
        self._config["engine"]["autoscale"]["replica_max"] = maximum
        self._config["engine"]["autoscale"]["type"] = "cpu"
        return self

    def autoscale_cpu_utilization(self, cpu_utilization_percentage: int):
        """Sets the average CPU metric to scale on in a percentage"""
        if "autoscale" not in self._config["engine"]:
            print(
                "Warn: min and max not set for autoscaling. These must be set to enable autoscaling"
            )
            self._config["engine"]["autoscale"] = {}
        self._config["engine"]["autoscale"][
            "cpu_utilization"
        ] = cpu_utilization_percentage
        return self

    def disable_autoscale(self):
        """Disables autoscaling in the deployment configuration"""
        if "autoscale" in ["engine"]:
            del self._config["engine"]["autoscale"]
        return self

    def cpus(self, core_count: int) -> "DeploymentConfigBuilder":
        self._config["engine"]["cpu"] = core_count
        if "resources" not in self._config["engine"]:
            self._config["engine"]["resources"] = {"limits": {}, "requests": {}}
        self._config["engine"]["resources"]["limits"]["cpu"] = core_count
        self._config["engine"]["resources"]["requests"]["cpu"] = core_count
        return self

    def memory(self, memory_spec: str) -> "DeploymentConfigBuilder":
        if "resources" not in self._config["engine"]:
            self._config["engine"]["resources"] = {"limits": {}, "requests": {}}
        self._config["engine"]["resources"]["limits"]["memory"] = memory_spec
        self._config["engine"]["resources"]["requests"]["memory"] = memory_spec
        return self

    def lb_cpus(self, core_count: int) -> "DeploymentConfigBuilder":
        if "resources" not in self._config["enginelb"]:
            self._config["enginelb"]["resources"] = {"limits": {}, "requests": {}}
        self._config["enginelb"]["resources"]["limits"]["cpu"] = core_count
        self._config["enginelb"]["resources"]["requests"]["cpu"] = core_count
        return self

    def lb_memory(self, memory_spec: int) -> "DeploymentConfigBuilder":
        if "resources" not in self._config["enginelb"]:
            self._config["enginelb"]["resources"] = {"limits": {}, "requests": {}}
        self._config["enginelb"]["resources"]["limits"]["memory"] = memory_spec
        self._config["enginelb"]["resources"]["requests"]["memory"] = memory_spec
        return self

    def build(self) -> DeploymentConfig:
        return DeploymentConfig(self._config)
