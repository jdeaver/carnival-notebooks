from .notify import AlertConfiguration
from .deployment import Deployment
from .deployment_config import DeploymentConfig, DeploymentConfigBuilder
from .model_config import ModelConfig
from .object import *

from typing import cast, Any, Dict, List, Optional, TYPE_CHECKING

import datetime
from dateutil import parser as dateparse

if TYPE_CHECKING:
    # Imports that happen below in methods to fix circular import dependency
    # issues need to also be specified here to satisfy mypy type checking.
    from .client import Client
    from .pipeline import Pipeline


class PipelineVariant(Object):
    def __init__(self, client: Optional["Client"], data: Dict[str, Any]) -> None:
        self.client = client
        assert client is not None
        super().__init__(gql_client=client._gql_client, data=data)

    def _fill(self, data: Dict[str, Any]) -> None:
        from .pipeline import Pipeline  # avoids circular imports

        for required_attribute in ["id"]:
            if required_attribute not in data:
                raise RequiredAttributeMissing(
                    self.__class__.__name__, required_attribute
                )
        self._id = data["id"]

        self._create_time = (
            dateparse.isoparse(data["created_at"])
            if "created_at" in data
            else DehydratedValue()
        )
        self._last_update_time = (
            dateparse.isoparse(data["updated_at"])
            if "updated_at" in data
            else DehydratedValue()
        )
        self._name = value_if_present(data, "version")
        self._definition = value_if_present(data, "definition")
        self._pipeline = (
            Pipeline(client=self.client, data=data["pipeline"])
            if "pipeline" in data
            else DehydratedValue()
        )
        self._deployments = (
            [
                Deployment(
                    client=self.client,
                    data=elem["deployment"],
                )
                for elem in data["deployment_pipeline_versions"]
            ]
            if "deployment_pipeline_versions" in data
            else DehydratedValue()
        )

    def _fetch_attributes(self) -> Dict[str, Any]:
        return self._gql_client.execute(
            gql.gql(
                """
            query PipelineVariantById($variant_id: bigint!) {
                pipeline_version_by_pk(id: $variant_id) {
                    id
                    created_at
                    updated_at
                    version
                    definition
                    pipeline {
                        id
                    }
                    deployment_pipeline_versions {
                        created_at
                        updated_at
                        deployment {
                            id
                        }
                    }
                }
            }
                """
            ),
            variable_values={
                "variant_id": self._id,
            },
        )["pipeline_version_by_pk"]

    def id(self) -> int:
        return self._id

    @rehydrate("_create_time")
    def create_time(self) -> datetime.datetime:
        return cast(datetime.datetime, self._create_time)

    @rehydrate("_last_update_time")
    def last_update_time(self) -> datetime.datetime:
        return cast(datetime.datetime, self._last_update_time)

    @rehydrate("_name")
    def name(self) -> str:
        return cast(str, self._name)

    @rehydrate("_definition")
    def definition(self) -> Dict[str, Any]:
        return cast(Dict[str, Any], self._definition)

    @rehydrate("_pipeline")
    def pipeline(self) -> "Pipeline":
        from .pipeline import Pipeline

        return cast(Pipeline, self._pipeline)

    @rehydrate("_deployments")
    def deployments(self) -> List[Deployment]:
        return cast(List[Deployment], self._deployments)

    def deploy(
        self,
        deployment_name: str,
        model_configs: List[ModelConfig],
        config: Optional[DeploymentConfig] = None,
    ) -> Deployment:
        """Deploys this PipelineVariant.

        :param str deployment_name: Name of the new Deployment. Must be unique
            across all deployments.
        :param List[ModelConfig] model_configs: List of the configured models to
        use. These must be the same ModelConfigs used when creating the
            Pipeline.
        :param Optional[DeploymentConfig] config: Deployment configuration to use.
        :return: A Deployment object for the resulting deployment.
        :rtype: Deployment
        """
        if config is None:
            config = DeploymentConfigBuilder().build()

        assert self.client is not None
        data = self.client._gql_client.execute(
            gql.gql(
                """
                mutation CreateDeployment($deploy_id: String!, $pipeline_id: bigint, $deployed: Boolean, $engine_config: jsonb) {
            insert_deployment(
                    objects: {
                        deployed: $deployed,
                        deploy_id: $deploy_id,
                        pipeline_id: $pipeline_id,
                        engine_config:  $engine_config}
                    on_conflict: {
                        constraint: deployment_pipeline_id_key,
                        update_columns: [updated_at, deployed, engine_config]
                    }
                ) {
                    returning {
                        id
                        deployed
                        deployment_name: deploy_id
                        engine_config
                        created_at
                    }
                }
            }
            """
            ),
            variable_values={
                "deploy_id": deployment_name,
                "deployed": True,
                "pipeline_id": self.pipeline().id(),
                "engine_config": config,
            },
        )
        deployment = Deployment(
            client=self.client, data=data["insert_deployment"]["returning"][0]
        )

        # Insert all model configs
        for mc in model_configs:
            self._gql_client.execute(
                gql.gql(
                    """
                mutation InsertDeploymentModelConfig(
                    $deployment_id: bigint
                    $model_config_id: bigint
                    $pipeline_version_pk_id: bigint
                ) {
                    insert_deployment_model_configs(
                        objects: {
                        deployment_id: $deployment_id
                        model_config_id: $model_config_id
                        pipeline_version_pk_id: $pipeline_version_pk_id
                        }
                    ) {
                        returning {
                        id
                        }
                    }
                    }
                """
                ),
                variable_values={
                    "deployment_id": deployment.id(),
                    "model_config_id": mc.id(),
                    "pipeline_version_pk_id": self.id(),
                },
            )

        self._gql_client.execute(
            gql.gql(
                """
                mutation InsertDeploymentPipelineVersion(
                    $deployment_id: bigint
                    $pipeline_version_pk_id: bigint
                ) {
                insert_deployment_pipeline_version(
                    objects: {
                    deployment_id: $deployment_id
                    pipeline_version_pk_id: $pipeline_version_pk_id
                    }
                ) {
                    returning {
                    id
                    }
                }
            }
            """
            ),
            variable_values={
                "deployment_id": deployment.id(),
                "pipeline_version_pk_id": self.id(),
            },
        )

        deployment._rehydrate()
        return deployment.wait_for_running()
