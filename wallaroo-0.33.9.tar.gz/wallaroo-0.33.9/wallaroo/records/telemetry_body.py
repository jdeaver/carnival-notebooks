###!!!!!!!
## Generated: npx quicktype --src api/json/telemetry/wallaroo-api-telemetry-data-v1.json --src-lang schema --lang python  >> sdk/wallaroo/records/telemetry_body.py
###!!!!!!!
# This code parses date/times, so please
#
#     pip install python-dateutil
#
# To use this code, make sure you
#
#     import json
#
# and then, to convert JSON from a string, do
#
#     result = wallaroo_api_telemetry_data_v1_from_dict(json.loads(json_string))

from typing import Any, List, TypeVar, Callable, Type, cast
from uuid import UUID
from datetime import datetime
import dateutil.parser


T = TypeVar("T")


def from_none(x: Any) -> Any:
    assert x is None
    return x


def from_int(x: Any) -> int:
    assert isinstance(x, int) and not isinstance(x, bool)
    return x


def from_str(x: Any) -> str:
    assert isinstance(x, str)
    return x


def from_list(f: Callable[[Any], T], x: Any) -> List[T]:
    assert isinstance(x, list)
    return [f(y) for y in x]


def to_class(c: Type[T], x: Any) -> dict:
    assert isinstance(x, c)
    return cast(Any, x).to_dict()


def from_datetime(x: Any) -> datetime:
    return dateutil.parser.parse(x)


def from_bool(x: Any) -> bool:
    assert isinstance(x, bool)
    return x


class ModelConfig:
    filter_threshold: None
    id: int
    runtime: str

    def __init__(self, filter_threshold: None, id: int, runtime: str) -> None:
        self.filter_threshold = filter_threshold
        self.id = id
        self.runtime = runtime

    @staticmethod
    def from_dict(obj: Any) -> "ModelConfig":
        assert isinstance(obj, dict)
        filter_threshold = from_none(obj.get("filter_threshold"))
        id = from_int(obj.get("id"))
        runtime = from_str(obj.get("runtime"))
        return ModelConfig(filter_threshold, id, runtime)

    def to_dict(self) -> dict:
        result: dict = {}
        result["filter_threshold"] = from_none(self.filter_threshold)
        result["id"] = from_int(self.id)
        result["runtime"] = from_str(self.runtime)
        return result


class ModelInferenceModel:
    name: str
    sha: str
    version: UUID

    def __init__(self, name: str, sha: str, version: UUID) -> None:
        self.name = name
        self.sha = sha
        self.version = version

    @staticmethod
    def from_dict(obj: Any) -> "ModelInferenceModel":
        assert isinstance(obj, dict)
        name = from_str(obj.get("name"))
        sha = from_str(obj.get("sha"))
        version = UUID(obj.get("version"))
        return ModelInferenceModel(name, sha, version)

    def to_dict(self) -> dict:
        result: dict = {}
        result["name"] = from_str(self.name)
        result["sha"] = from_str(self.sha)
        result["version"] = str(self.version)
        return result


class ModelInference:
    models: List[ModelInferenceModel]

    def __init__(self, models: List[ModelInferenceModel]) -> None:
        self.models = models

    @staticmethod
    def from_dict(obj: Any) -> "ModelInference":
        assert isinstance(obj, dict)
        models = from_list(ModelInferenceModel.from_dict, obj.get("models"))
        return ModelInference(models)

    def to_dict(self) -> dict:
        result: dict = {}
        result["models"] = from_list(
            lambda x: to_class(ModelInferenceModel, x), self.models
        )
        return result


class Step:
    model_inference: ModelInference

    def __init__(self, model_inference: ModelInference) -> None:
        self.model_inference = model_inference

    @staticmethod
    def from_dict(obj: Any) -> "Step":
        assert isinstance(obj, dict)
        model_inference = ModelInference.from_dict(obj.get("ModelInference"))
        return Step(model_inference)

    def to_dict(self) -> dict:
        result: dict = {}
        result["ModelInference"] = to_class(ModelInference, self.model_inference)
        return result


class Definition:
    id: str
    steps: List[Step]

    def __init__(self, id: str, steps: List[Step]) -> None:
        self.id = id
        self.steps = steps

    @staticmethod
    def from_dict(obj: Any) -> "Definition":
        assert isinstance(obj, dict)
        id = from_str(obj.get("id"))
        steps = from_list(Step.from_dict, obj.get("steps"))
        return Definition(id, steps)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = from_str(self.id)
        result["steps"] = from_list(lambda x: to_class(Step, x), self.steps)
        return result


class PipelineVariant:
    create_time: datetime
    definition: Definition
    last_update_time: datetime
    name: UUID

    def __init__(
        self,
        create_time: datetime,
        definition: Definition,
        last_update_time: datetime,
        name: UUID,
    ) -> None:
        self.create_time = create_time
        self.definition = definition
        self.last_update_time = last_update_time
        self.name = name

    @staticmethod
    def from_dict(obj: Any) -> "PipelineVariant":
        assert isinstance(obj, dict)
        create_time = from_datetime(obj.get("create_time"))
        definition = Definition.from_dict(obj.get("definition"))
        last_update_time = from_datetime(obj.get("last_update_time"))
        name = UUID(obj.get("name"))
        return PipelineVariant(create_time, definition, last_update_time, name)

    def to_dict(self) -> dict:
        result: dict = {}
        result["create_time"] = self.create_time.isoformat()
        result["definition"] = to_class(Definition, self.definition)
        result["last_update_time"] = self.last_update_time.isoformat()
        result["name"] = str(self.name)
        return result


class Deployment:
    deployed: bool
    model_configs: List[ModelConfig]
    name: str
    pipeline_variants: List[PipelineVariant]

    def __init__(
        self,
        deployed: bool,
        model_configs: List[ModelConfig],
        name: str,
        pipeline_variants: List[PipelineVariant],
    ) -> None:
        self.deployed = deployed
        self.model_configs = model_configs
        self.name = name
        self.pipeline_variants = pipeline_variants

    @staticmethod
    def from_dict(obj: Any) -> "Deployment":
        assert isinstance(obj, dict)
        deployed = from_bool(obj.get("deployed"))
        model_configs = from_list(ModelConfig.from_dict, obj.get("model_configs"))
        name = from_str(obj.get("name"))
        pipeline_variants = from_list(
            PipelineVariant.from_dict, obj.get("pipeline_variants")
        )
        return Deployment(deployed, model_configs, name, pipeline_variants)

    def to_dict(self) -> dict:
        result: dict = {}
        result["deployed"] = from_bool(self.deployed)
        result["model_configs"] = from_list(
            lambda x: to_class(ModelConfig, x), self.model_configs
        )
        result["name"] = from_str(self.name)
        result["pipeline_variants"] = from_list(
            lambda x: to_class(PipelineVariant, x), self.pipeline_variants
        )
        return result


class WelcomeModel:
    file_name: str
    last_update: datetime
    name: str
    version: UUID

    def __init__(
        self, file_name: str, last_update: datetime, name: str, version: UUID
    ) -> None:
        self.file_name = file_name
        self.last_update = last_update
        self.name = name
        self.version = version

    @staticmethod
    def from_dict(obj: Any) -> "WelcomeModel":
        assert isinstance(obj, dict)
        file_name = from_str(obj.get("file_name"))
        last_update = from_datetime(obj.get("last_update"))
        name = from_str(obj.get("name"))
        version = UUID(obj.get("version"))
        return WelcomeModel(file_name, last_update, name, version)

    def to_dict(self) -> dict:
        result: dict = {}
        result["file_name"] = from_str(self.file_name)
        result["last_update"] = self.last_update.isoformat()
        result["name"] = from_str(self.name)
        result["version"] = str(self.version)
        return result


class Pipeline:
    create_time: datetime
    name: str

    def __init__(self, create_time: datetime, name: str) -> None:
        self.create_time = create_time
        self.name = name

    @staticmethod
    def from_dict(obj: Any) -> "Pipeline":
        assert isinstance(obj, dict)
        create_time = from_datetime(obj.get("create_time"))
        name = from_str(obj.get("name"))
        return Pipeline(create_time, name)

    def to_dict(self) -> dict:
        result: dict = {}
        result["create_time"] = self.create_time.isoformat()
        result["name"] = from_str(self.name)
        return result


class User:
    email: str
    username: str

    def __init__(self, email: str, username: str) -> None:
        self.email = email
        self.username = username

    @staticmethod
    def from_dict(obj: Any) -> "User":
        assert isinstance(obj, dict)
        email = from_str(obj.get("email"))
        username = from_str(obj.get("username"))
        return User(email, username)

    def to_dict(self) -> dict:
        result: dict = {}
        result["email"] = from_str(self.email)
        result["username"] = from_str(self.username)
        return result


class WorkspaceModel:
    file_name: str
    name: str

    def __init__(self, file_name: str, name: str) -> None:
        self.file_name = file_name
        self.name = name

    @staticmethod
    def from_dict(obj: Any) -> "WorkspaceModel":
        assert isinstance(obj, dict)
        file_name = from_str(obj.get("file_name"))
        name = from_str(obj.get("name"))
        return WorkspaceModel(file_name, name)

    def to_dict(self) -> dict:
        result: dict = {}
        result["file_name"] = from_str(self.file_name)
        result["name"] = from_str(self.name)
        return result


class Workspace:
    archived: bool
    created_at: datetime
    models: List[WorkspaceModel]
    name: str

    def __init__(
        self,
        archived: bool,
        created_at: datetime,
        models: List[WorkspaceModel],
        name: str,
    ) -> None:
        self.archived = archived
        self.created_at = created_at
        self.models = models
        self.name = name

    @staticmethod
    def from_dict(obj: Any) -> "Workspace":
        assert isinstance(obj, dict)
        archived = from_bool(obj.get("archived"))
        created_at = from_datetime(obj.get("created_at"))
        models = from_list(WorkspaceModel.from_dict, obj.get("models"))
        name = from_str(obj.get("name"))
        return Workspace(archived, created_at, models, name)

    def to_dict(self) -> dict:
        result: dict = {}
        result["archived"] = from_bool(self.archived)
        result["created_at"] = self.created_at.isoformat()
        result["models"] = from_list(lambda x: to_class(WorkspaceModel, x), self.models)
        result["name"] = from_str(self.name)
        return result


class WallarooAPITelemetryDataV1:
    deployments: List[Deployment]
    models: List[WelcomeModel]
    pipelines: List[Pipeline]
    users: List[User]
    workspaces: List[Workspace]

    def __init__(
        self,
        deployments: List[Deployment],
        models: List[WelcomeModel],
        pipelines: List[Pipeline],
        users: List[User],
        workspaces: List[Workspace],
    ) -> None:
        self.deployments = deployments
        self.models = models
        self.pipelines = pipelines
        self.users = users
        self.workspaces = workspaces

    @staticmethod
    def from_dict(obj: Any) -> "WallarooAPITelemetryDataV1":
        assert isinstance(obj, dict)
        deployments = from_list(Deployment.from_dict, obj.get("deployments"))
        models = from_list(WelcomeModel.from_dict, obj.get("models"))
        pipelines = from_list(Pipeline.from_dict, obj.get("pipelines"))
        users = from_list(User.from_dict, obj.get("users"))
        workspaces = from_list(Workspace.from_dict, obj.get("workspaces"))
        return WallarooAPITelemetryDataV1(
            deployments, models, pipelines, users, workspaces
        )

    def to_dict(self) -> dict:
        result: dict = {}
        result["deployments"] = from_list(
            lambda x: to_class(Deployment, x), self.deployments
        )
        result["models"] = from_list(lambda x: to_class(WelcomeModel, x), self.models)
        result["pipelines"] = from_list(lambda x: to_class(Pipeline, x), self.pipelines)
        result["users"] = from_list(lambda x: to_class(User, x), self.users)
        result["workspaces"] = from_list(
            lambda x: to_class(Workspace, x), self.workspaces
        )
        return result


def wallaroo_api_telemetry_data_v1_from_dict(s: Any) -> WallarooAPITelemetryDataV1:
    return WallarooAPITelemetryDataV1.from_dict(s)


def wallaroo_api_telemetry_data_v1_to_dict(x: WallarooAPITelemetryDataV1) -> Any:
    return to_class(WallarooAPITelemetryDataV1, x)
